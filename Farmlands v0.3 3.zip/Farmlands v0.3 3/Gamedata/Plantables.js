Plantables.push({

        //Plant data.
        //Remember that ID = place in stack.
        Name: "Carrots",
        Cost: 4,
        Color: '#fcc36d',
        FinalCost: 40,
        DaysToGrow: 20,
        WaterUse: 3,
        CropHealth: 4, //days till death in bad conditions

        //Permanent FX upon planting.
        PlantLandCost: 0,
        PlantLandIrrigation: 0,
        PlantLandFertility: 0,
        PlantLandCropResistance: 0,

        //Permanent FX upon harvesting.
        LandCost: 0,
        LandIrrigation: 0,
        LandWaterRetention: 0,
        LandGrowSpeed: 0,
        LandFertility: 0,
        LandTemp: 0,
        LandCropResistance: 0,




        //Temporary FX upon harvesting. (Removed after next harvest.)
        TempCost: 0
    });